/// The Linux implementation of `network_info_plus`.
library network_info_plus_linux;

export 'src/network_info.dart';
