## 1.1.2

- Bump nm dependency to 0.5.0

## 1.1.1

- Update Flutter dependencies

## 1.1.0

- Port to nm.dart
- Add IPv6, gateway IP, subnet mask, broadcast

## 1.0.2

- Upgrade D-Bus package dependency

## 1.0.1

- Improve documentation

## 1.0.0

- Migrate to null-safety.

## 0.1.1

- Address pub score.

## 0.1.0

- Initial release for Linux.
