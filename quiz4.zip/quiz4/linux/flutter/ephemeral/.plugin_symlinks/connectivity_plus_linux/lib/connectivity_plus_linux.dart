/// The Linux implementation of `connectivity_plus`.
library connectivity_plus_linux;

export 'src/connectivity.dart';
