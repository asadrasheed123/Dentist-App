## 1.2.2

- Revert changes in 1.2.1

## 1.2.1

- Fixes a crash when adding a listener to a destroyed channel

## 1.2.0

- Add ethernet as connectivity result.

## 1.1.0

- Update connectivity plus

## 1.0.2

- Update connectivity plus

## 1.0.1

- Improve documentation

## 1.0.0

- Migrated to null safety

## 0.1.1

- Address pub score

## 0.1.0

- Initial release for Windows.
