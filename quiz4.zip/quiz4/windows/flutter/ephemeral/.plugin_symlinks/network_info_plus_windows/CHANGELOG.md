## 1.0.2

- Fix include order: #242

## 1.0.1

- Improve documentation

## 1.0.0

- Migrate to null-safety.

## 0.1.1

- Address pub score.

## 0.1.0

- Initial release for Windows.
