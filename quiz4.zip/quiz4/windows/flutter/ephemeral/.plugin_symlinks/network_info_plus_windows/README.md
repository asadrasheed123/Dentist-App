# Network Info Plus Windows

[![Flutter Community: network_info_plus_windows](https://fluttercommunity.dev/_github/header/network_info_plus_windows)](https://github.com/fluttercommunity/community)

[![pub package](https://img.shields.io/pub/v/network_info_plus_windows.svg)](https://pub.dev/packages/network_info_plus_windows)

The Windows implementation of [`network_info_plus`](https://pub.dev/packages/network_info_plus).

## Usage

This package is already included as part of the `network_info_plus` package dependency, and will
be included when using `network_info_plus` as normal.
