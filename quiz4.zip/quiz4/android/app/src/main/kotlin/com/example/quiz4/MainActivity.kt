package com.example.quiz4

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
