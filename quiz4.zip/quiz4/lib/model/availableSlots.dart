class availableSlots {
  final String name;

  availableSlots({required this.name});
}
