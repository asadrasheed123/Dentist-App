import 'dart:ui';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:file_picker/file_picker.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';

import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get_navigation/get_navigation.dart';
import 'package:get/instance_manager.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import 'package:http/http.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:typed_data';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:flutter/services.dart';
//final _formKey = GlobalKey<FormState>();
class contact_us extends StatefulWidget {
  const contact_us({ Key? key }) : super(key: key);

  @override
  State<contact_us> createState() => _contact_usState();

 }    
 final String lat = "31.975697";
  final String lng = "35.859400";
   final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  String? _fileName;
  List<PlatformFile>? _paths;
  String? _directoryPath;
  String? _extension;
  bool _loadingPath = false;
  bool _multiPick = false;
  FileType _pickingType = FileType.any;
  TextEditingController _controller = TextEditingController();
  

  _launchMap() async {
    final String googleMapsUrl = "comgooglemaps://?center=$lat,$lng";
    final String appleMapsUrl = "https://maps.apple.com/?q=$lat,$lng";

    if (await canLaunch(googleMapsUrl)) {
      await launch(googleMapsUrl);
    }
    if (await canLaunch(appleMapsUrl)) {
      await launch(appleMapsUrl, forceSafariVC: false);
    } else {
      throw "Couldn't launch URL";
    }
  }



class _contact_usState extends State<contact_us> {
   final _formKey = GlobalKey<FormState>();
   var name = "";
  var email = "";
  var subject = "";
  var message = "";
   final nameController = TextEditingController();
  final emailController = TextEditingController();
    final subjectController = TextEditingController();
     final messageController = TextEditingController();
     static const _initialCameraPosition = CameraPosition(
    target: LatLng(31.975697, 35.859400),
    zoom: 11.5,
  );
 @override

  void dispose() {
    // Clean up the controller when the widget is disposed.
    emailController.dispose();
    nameController.dispose();
    subjectController.dispose();
    messageController.dispose();
       _googleMapController.dispose();
      // _marker.addAll(_List);

    super.dispose();
  }
  @override
void initState() {
  super.initState();


}
  late GoogleMapController _googleMapController;
  //Map<MarkerId, Marker> markers = <MarkerId, Marker>{};

 final Set<Marker> markers = new Set(); //markers for google map
  static const LatLng showLocation = const LatLng(31.3341,74.2359);


  // #EEF9FF;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
   home: Scaffold( resizeToAvoidBottomInset: false,

      body: SafeArea(
        child: ListView(children: [
          SizedBox(height: 10,),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Container(
                   height: 390,


                   child: Card(
                      color: HexColor("#EEF9FF"),
                      elevation: 4,
                     child: Padding(
                       padding: const EdgeInsets.all(12.0),
                       child: Column(


                         children: [

                                   Column(children: [
                                     SizedBox(height: 15,),
                                      Row(


                                      children: [
                                        Text("CONTACT US",style: TextStyle(fontSize: 21, color: Colors.black,), ),
                                      ],
                                    ),
                                    SizedBox(height: 15,),
                                      Row(

                                      children: [
                                 Text("Feel Free To Contact Us",style: TextStyle(fontSize: 25, color: Colors.black, fontWeight: FontWeight.bold),),

                                    ],), SizedBox(height: 18,),
                                         InkWell(
                                           onTap: () {

                                                _launchMap();

                                           },
                                           child: ListTile(
                                                                        leading:Icon(Icons.place, size: 28,color: Colors.black,) ,

                                                                        title:   Text("Our Office",style: TextStyle(fontSize: 20, color: Colors.black, fontWeight: FontWeight.bold),),
                                                                        subtitle:   Text("Superior University ",style: TextStyle(fontSize: 18,  ),),


                                                                           ),
                                         ),
                                     InkWell(
                                       onTap: ()async{

                                         String email = 'this.is.nfo@example.com';
    String subject = 'This is a email';
    String body = 'This is a email body';

    String emailUrl = "mailto:$email?subject=$subject&body=$body";

    if (await canLaunch(emailUrl)) {
      await launch(emailUrl);
    } else {
      throw "Error occured sending an email";
    }

                                       },
                                       child: ListTile(
                                                                    leading:Icon(Icons.email,size: 28,color: Colors.black,) ,

                                                                    title:   Text("Email Us",style: TextStyle(fontSize: 20, color: Colors.black, fontWeight: FontWeight.bold),),
                                                                    subtitle:   Text("Bsem-f18-083@superior.edu.pk",style: TextStyle(fontSize: 18, ),),


                                                                       ),
                                     ),
                                       InkWell(
                                     onTap: ()async{
                                        String telephoneNumber = '+923044138901';
                                                                        String telephoneUrl = "tel:$telephoneNumber";

                                                                       if (await canLaunch(telephoneUrl)) {
      await launch(telephoneUrl);
    } else{
       throw "Error occured trying to call that number.";
    }
                                     },
                                         child: ListTile(
                                                                      leading: Icon(Icons.call,size: 28,color: Colors.black,) ,




                                                                      title:   Text("Call Us",style: TextStyle(fontSize: 20, color: Colors.black, fontWeight: FontWeight.bold),),
                                                                      subtitle:   Text("+923044138901",style: TextStyle(fontSize: 18, ),),


                                                                         ),
                                       )




                                   ],),




                             SizedBox(height: 10,),
                         ],
                       ),
                     ),
                   ),

                 ),
              ),

                   Form(
          key: _formKey,
         child: Padding(
           padding: EdgeInsets.symmetric(vertical: 20, horizontal: 30),
            child: Column(
              children: [
                Container(
                  margin: EdgeInsets.symmetric(vertical: 10.0),
                  child:  TextFormField(
              //  autocorrect: true,

                decoration: InputDecoration(
                  hintText: 'Your Name',
                  prefixIcon: Icon(Icons.person),
                  hintStyle: TextStyle(color: Colors.grey),
                   border: OutlineInputBorder(),
                    errorStyle:
                          TextStyle(color: Colors.redAccent, fontSize: 15),

                  filled: true,
                  fillColor:  HexColor("#EEF9FF"),
                  enabledBorder: OutlineInputBorder(
                  //  borderRadius: BorderRadius.all(Radius.circular(12.0)),
                    borderSide: BorderSide(color: HexColor("#EEF9FF"), width: 2),
                   ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.all(Radius.circular(10.0)),
                    borderSide: BorderSide(color:  HexColor("#EEF9FF"), width: 2),
                  ),
                ),
                 controller: nameController,
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please Enter Name';
                        }
                        return null;
                      },

                ),


                ),


                Container(
                  margin: EdgeInsets.symmetric(vertical: 10.0),
                  child:  TextFormField(
              //  autocorrect: true,

                decoration: InputDecoration(
                  hintText: 'Your Email',
                  prefixIcon: Icon(Icons.email),
                  hintStyle: TextStyle(color: Colors.grey),
                   border: OutlineInputBorder(),
                    errorStyle:
                          TextStyle(color: Colors.redAccent, fontSize: 15),

                  filled: true,
                  fillColor:  HexColor("#EEF9FF"),
                  enabledBorder: OutlineInputBorder(
                  //  borderRadius: BorderRadius.all(Radius.circular(12.0)),
                    borderSide: BorderSide(color: HexColor("#EEF9FF"), width: 2),
                   ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.all(Radius.circular(10.0)),
                    borderSide: BorderSide(color: HexColor("#EEF9FF"), width: 2),
                  ),
                ),
                 controller: emailController,
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please Enter Email';
                        } else if (!value.contains('@')) {
                          return 'Please Enter Valid Email';
                        }
                        return null;
                      },

                ),


                ),

                Container(
                  margin: EdgeInsets.symmetric(vertical: 10.0),
                  child:  TextFormField(
              //  autocorrect: true,

                decoration: InputDecoration(
                  hintText: 'Subject',
                  prefixIcon: Icon(Icons.text_fields),
                  hintStyle: TextStyle(color: Colors.grey),
                   border: OutlineInputBorder(),
                    errorStyle:
                          TextStyle(color: Colors.redAccent, fontSize: 15),

                  filled: true,
                  fillColor:  HexColor("#EEF9FF"),
                  enabledBorder: OutlineInputBorder(
                  //  borderRadius: BorderRadius.all(Radius.circular(12.0)),
                    borderSide: BorderSide(color: HexColor("#EEF9FF"), width: 2),
                   ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.all(Radius.circular(10.0)),
                    borderSide: BorderSide(color:  HexColor("#EEF9FF"), width: 2),
                  ),
                ),
                controller: subjectController,

                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please Enter subject';
                        }
                        return null;
                      },

                ),


                ),
                 Container(
                  margin: EdgeInsets.symmetric(vertical: 10.0),
                  child:  TextFormField(
              //  autocorrect: true,
               maxLines: 5,

                decoration: InputDecoration(
                  hintText: 'Message',
                //  prefixIcon: Icon(Icons.message),
                  hintStyle: TextStyle(color: Colors.grey),
                   border: OutlineInputBorder(),
                    errorStyle:
                          TextStyle(color: Colors.redAccent, fontSize: 15),

                  filled: true,
                  fillColor:  HexColor("#EEF9FF"),
                  enabledBorder: OutlineInputBorder(
                  //  borderRadius: BorderRadius.all(Radius.circular(12.0)),
                    borderSide: BorderSide(color: HexColor("#EEF9FF"), width: 2),
                   ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.all(Radius.circular(10.0)),
                    borderSide: BorderSide(color:  HexColor("#EEF9FF"), width: 2),
                  ),
                ),
                 controller: messageController,
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please Enter message';
                        }
                        return null;
                      },

                ),


                ),



                 SizedBox(height: 10,),
                     Column(
                    children: [
                      MaterialButton(
                        color: Color.fromARGB(255, 1, 11, 66),
                        minWidth: double.infinity,
                        height: 50,
                          onPressed: ()  async{
                  if (_formKey.currentState!.validate()) {
                                setState(() {
                               email = emailController.text;
                            name = nameController.text;
                            subject = subjectController.text;
                            message = messageController.text;

                                });
                                int id = DateTime.now().microsecondsSinceEpoch;
                                try{
                                  await    FirebaseFirestore.instance.collection('contactus').doc('$id').set({"name" : nameController.text, "email" : emailController.text, "subject" : subjectController.text, "message" : messageController.text});
                                  Fluttertoast.showToast(msg: "Data Send");
                                } catch (e){
                                  Fluttertoast.showToast(msg: "some error occured");
                                }


                              }


          },

                        shape: RoundedRectangleBorder(
                          side: BorderSide(
                            color: Colors.indigo,
                          ),
                         // borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(
                          "Send Message",
                          style: TextStyle(
                            fontWeight: FontWeight.w600,
                            fontSize: 18,color: Colors.white,
                          ),

                        ),
                      ),
                    ],
                ),
                SizedBox(height: 30,),
              Stack(children: [
                 Container(
                height: 460.0,
                width: double.infinity,

                  alignment: Alignment.center,

                  child:  GoogleMap(
                        zoomGesturesEnabled: true, //enable Zoom in, out on map
                    initialCameraPosition: CameraPosition( //innital position in map
                      target: showLocation, //initial position
                      zoom: 18.0, //initial zoom level
                    ),
                    markers: getmarkers(), //markers to sho
                    //  markers: Set<Marker>.of(_marker),
                      // myLocationButtonEnabled: false,
                      // zoomControlsEnabled: false,
                    //  initialCameraPosition: _initialCameraPosition,
                      onMapCreated: (controller) =>
                          _googleMapController = controller,
                    ),


              ),
                 SizedBox(height: 10,),


              ],)
              ],
            ),
          ),
        ),
        ],),
      ),
   )
    );
  }

    Set<Marker> getmarkers() { //markers to place on map
    setState(() {
      markers.add(Marker( //add first marker
        markerId: MarkerId(showLocation.toString()),
        position: showLocation, //position of marker
        infoWindow: InfoWindow( //popup info
          title: 'Superior Dental Clinic',
          snippet: 'Abdullah Bhai',
        ),
        icon: BitmapDescriptor.defaultMarker, //Icon for Marker
      ));

    });

    return markers;
  }
}