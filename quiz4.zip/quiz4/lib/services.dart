

import 'package:before_after/before_after.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:hexcolor/hexcolor.dart';

import 'package:http/http.dart';
import 'package:loading_indicator/loading_indicator.dart';
import 'package:quiz4/model/before_after.dart';
import 'package:quiz4/model/services.dart';
import 'package:quiz4/service/costmetic_dencity.dart';
import 'package:quiz4/service/dental_bridge.dart';
import 'package:quiz4/service/root-treatment.dart';
import 'package:quiz4/service/teth_whitnes.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:typed_data';
import 'package:carousel_slider/carousel_slider.dart';

import 'service/dental_implement.dart';


class Services extends StatefulWidget {
  const Services({ Key? key }) : super(key: key);

  @override
  State<Services> createState() => _ServicesState();
}

class _ServicesState extends State<Services> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        debugShowCheckedModeBanner: false,
        home: Scaffold(    backgroundColor: Color.fromARGB(223, 255, 253, 253),

          body: SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child:

              ListView(children: [
                SizedBox(height: 30,),
                Row(

                  children: [

                    Text("Our Services:", style: TextStyle(fontSize: 25 , color:  Color.fromARGB(255, 1, 11, 66) ,fontWeight: FontWeight.bold,), ),
                  ],),
                Container(height: 260,
                  child:  Image(image: AssetImage('images/cosmetic_dentistry.jpg',), fit: BoxFit.fill,),
                ),
                SizedBox(
                  height: 60,
                  child: Container(
                    color:  HexColor("#EEF9FF"),
                    child:  Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text("Cosmetic Dentistry ", style: TextStyle(fontSize: 20 , color:  Color.fromARGB(255, 1, 11, 66) ), ),
                      ],),),
                ),
                SizedBox(height: 10,),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                ),
                Container(height: 260,
                  child:  Image(image: AssetImage('images/dental_implants.jpg',), fit: BoxFit.fill,),
                ),
                SizedBox(
                  height: 60,
                  child: Container(
                    color:  HexColor("#EEF9FF"),
                    child:  Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text("Dental Implants ", style: TextStyle(fontSize: 20 , color:  Color.fromARGB(255, 1, 11, 66) ), ),
                      ],),),
                ),
                SizedBox(height: 10,),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                ),
                Container(height: 260,
                  child:  Image(image: AssetImage('images/traditional-dental-bridge-300x225.jpg',), fit: BoxFit.fill,),
                ),
                SizedBox(
                  height: 60,
                  child: Container(
                    color:  HexColor("#EEF9FF"),
                    child:  Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text("Dental Bridges ", style: TextStyle(fontSize: 20 , color:  Color.fromARGB(255, 1, 11, 66) ), ),
                      ],),),
                ),
                SizedBox(height: 10,),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                ),
                Container(height: 260,
                  child:  Image(image: AssetImage('images/teeth_whitening.png',), fit: BoxFit.fill,),
                ),
                SizedBox(
                  height: 60,
                  child: Container(
                    color:  HexColor("#EEF9FF"),
                    child:  Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text("Teeth Whitening", style: TextStyle(fontSize: 20 , color:  Color.fromARGB(255, 1, 11, 66) ), ),
                      ],),),
                ),
                SizedBox(height: 10,),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                ),
                Container(height: 260,
                  child:  Image(image: AssetImage('images/what-is-root-canal-treatment.jpg',), fit: BoxFit.fill,),
                ),
                SizedBox(
                  height: 60,
                  child: Container(
                    color:  HexColor("#EEF9FF"),
                    child:  Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text("Root Treatment", style: TextStyle(fontSize: 20 , color:  Color.fromARGB(255, 1, 11, 66) ), ),
                      ],),),
                ),
                SizedBox(height: 10,),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                ),
              ],
              ),
            ),
          ),
        )
    );
  }
}