
import 'dart:convert';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_navigation/src/extension_navigation.dart';
import 'package:get/get_navigation/src/snackbar/snackbar.dart';
import 'package:hexcolor/hexcolor.dart';

import 'package:http/http.dart' as http;
import 'package:http/http.dart' ;
import 'package:loading_indicator/loading_indicator.dart';


import 'NavigationBar.dart';

var token;
class LoginUser extends StatelessWidget {
  const LoginUser({ Key? key }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return  Login ();
  }
}
class Login extends StatefulWidget {
  Login({Key? key}) : super(key: key);

  @override
  _LoginState createState() => _LoginState();
}

class _LoginState extends State<Login> {
  final _formKey = GlobalKey<FormState>();

  var email = "";
  var password = "";
  bool isLoading = false;
 
  
    TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  // Create a text controller and use it to retrieve the current value
  // of the TextField.
  userLogin() async {
    isLoading = true;
    setState(() {});
    bool userNameExists;
    bool passwordExists;

    try {
      var authResult = await FirebaseFirestore.instance
          .collection('user')
          .where('name', isEqualTo: emailController.text)
          .get();
      userNameExists = authResult.docs.isNotEmpty;
      if (userNameExists) {
        var authResult = await FirebaseFirestore.instance
            .collection('user')
            .where('password', isEqualTo: passwordController.text.toLowerCase())
            .get();
        passwordExists = authResult.docs.isNotEmpty;
        if (passwordExists) {
          isLoading = false;
          setState(() {});
          Fluttertoast.showToast(msg: 'Successfully logged in');
          //NavigateToHome
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) =>MaterialYou()),
          );
        } else {
          isLoading = false;
          setState(() {});
          Fluttertoast.showToast(msg: 'Incorrect username or password');
        }
      } else {
        isLoading = false;
        setState(() {});
        Fluttertoast.showToast(msg: 'Incorrect username or password');
      }
    } catch (e) {
      isLoading = false;
      setState(() {});
      Fluttertoast.showToast(msg: 'Some error occurred');
    }
    }

  

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Column(children: [
         
             SizedBox(height: 40,),
           //    Row( mainAxisAlignment: MainAxisAlignment.start,
           //   children: [
           //    IconButton(onPressed: (){   Get.to(MaterialYou());}, icon: Icon(Icons.arrow_back_ios_new)),
           // ],),
           Padding(
            padding: const EdgeInsets.all(14.0),
            child: Row(
              
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                
                Container(
                                 height: 170,
                                width: 170,
                                 
                                  child: Image(image: AssetImage('images/logo.png',), fit: BoxFit.fill,),
                               ),
              ],
            ),
          ),
          Form(
          key: _formKey,
          child: Padding(
            padding: EdgeInsets.symmetric(vertical: 20, horizontal: 30),
            child: Column(
              children: [
                Container(
                  margin: EdgeInsets.symmetric(vertical: 10.0),
                  child:  TextFormField(
                    controller: emailController,
              //  autocorrect: true,
              
                decoration: InputDecoration(
                  hintText: 'Your Name',
                  prefixIcon: Icon(Icons.person),
                  hintStyle: TextStyle(color: Colors.grey),
                   border: OutlineInputBorder(),
                    errorStyle:
                          TextStyle(color: Colors.redAccent, fontSize: 15),
                          
                  filled: true,
                  fillColor:  HexColor("#EEF9FF"),
                  enabledBorder: OutlineInputBorder(
                  //  borderRadius: BorderRadius.all(Radius.circular(12.0)),
                    borderSide: BorderSide(color: HexColor("#EEF9FF"), width: 2),
                    
                   ),
                     
                   
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.all(Radius.circular(10.0)),
                    borderSide: BorderSide(color: HexColor("#EEF9FF"), width: 2),
                  ),
                ),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please Enter name';
                      }
                      return null;
                    },
                
                ),
                
      
                ),
              
                
                Container(
                  margin: EdgeInsets.symmetric(vertical: 10.0),
                  child:  TextFormField(
                    controller: passwordController,
              //  autocorrect: true,
                obscureText: true,
                decoration: InputDecoration(
                  hintText: 'Enter you password',
                  prefixIcon: Icon(Icons.lock),
                  hintStyle: TextStyle(color: Colors.grey),
                   border: OutlineInputBorder(),
                    errorStyle:
                          TextStyle(color: Colors.redAccent, fontSize: 15),
                          
                  filled: true,
                  fillColor:  HexColor("#EEF9FF"),
                  enabledBorder: OutlineInputBorder(
                  //  borderRadius: BorderRadius.all(Radius.circular(12.0)),
                    borderSide: BorderSide(color: HexColor("#EEF9FF"), width: 2),
                   ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.all(Radius.circular(10.0)),
                    borderSide: BorderSide(color:  HexColor("#EEF9FF"), width: 2),
                  ),
                ),
                validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please Enter password';
                        }
                        return null;
                      },
                
                ),
                
      
                ),
              
             
              
                 
                       SizedBox(height: 25,),
               
                     Column(
                    children: [
                      isLoading
                          ? Center(
                          child: SizedBox(
                              width: 80,
                              child: LoadingIndicator(
                                  indicatorType: Indicator.ballBeat,
                                  colors: [
                                    Theme.of(context).primaryColor,
                                  ],
                                  strokeWidth: 2,
                                  pathBackgroundColor:
                                  Theme.of(context).primaryColor)),
                          ):
                      MaterialButton(
                        color: Color.fromARGB(255, 1, 11, 66),
                        minWidth: double.infinity,
                        height: 50,
                          onPressed: ()  {
                              if (_formKey.currentState!.validate()) {
                                setState(() {
                               email = emailController.text;
                            password = passwordController.text;
                        
                                });
                               
                                  

                              
                  
                             
                                   userLogin();
                              }
          

                         
               
          
          },
                       
                        shape: RoundedRectangleBorder(
                          side: BorderSide(
                            color: Colors.indigo,
                          ),
                         // borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(
                          "Login",
                          style: TextStyle(
                            fontWeight: FontWeight.w600,
                            fontSize: 18,color: Colors.white,
                          ),
      
                        ),
                      ),
              //          Row( mainAxisAlignment: MainAxisAlignment.start,
              //   children: [
              //    Text(
              //             'Forgot Password',
              //             style: TextStyle(fontSize: 14.0, color: Colors.blue),
              //           ),
              // ],),
                    ],
                ),
                SizedBox(height: 10,),
               
              ],
            ),
          ),
        ),
        ],),
      )
      
      
      
      
      
      
    );
  }
}