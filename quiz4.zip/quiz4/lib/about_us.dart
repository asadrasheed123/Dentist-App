import 'package:flutter/material.dart';
import 'package:hexcolor/hexcolor.dart';
class About_us extends StatefulWidget {
  const About_us({ Key? key }) : super(key: key);

  @override
  State<About_us> createState() => _About_usState();
}

class _About_usState extends State<About_us> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
   home: Scaffold(    backgroundColor: Color.fromARGB(223, 255, 253, 253),

      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child:
          
           ListView(children: [
                      SizedBox(height: 30,),
                   Row(
                          
                          children: [
                          
                          Text("About Us:", style: TextStyle(fontSize: 25 , color:  Color.fromARGB(255, 1, 11, 66) ,fontWeight: FontWeight.bold,), ),
                        ],),
                        Container(height: 260,
                        child:  Image(image: AssetImage('images/about.png',), fit: BoxFit.fill,),
                        ),
             SizedBox(
               height: 60,
               child: Container(
                 color:  HexColor("#EEF9FF"),
                 child:  Row(
                   mainAxisAlignment: MainAxisAlignment.center,
                   children: [
                     Text("Best Dental Clinic in Lahore ", style: TextStyle(fontSize: 20 , color:  Color.fromARGB(255, 1, 11, 66) ), ),
                   ],),),
             ),
                        SizedBox(height: 10,),
                   Padding(
                     padding: const EdgeInsets.all(8.0),
                     child: Row(
                       children: const [
                         Expanded(
                           child: Text(
                         'We Aim To Provide The Best Dental Solution For Our Valued Patients. Being The Best Dentists In Lahore, Pakistan, We Offer Comprehensive Dental Aesthetic Services. We Address From Simple Dental Filling To Complexed Dental Procedures. Our Motto Is To Provide Our Patients With Minimum Invasive Dentistry For The Best Possible Results. Get an Appointment with best dentist in Lahore, Pakistan.',
                         style: TextStyle(fontSize: 15),
                         softWrap: false,
                          maxLines: 10,
                             overflow: TextOverflow.ellipsis,

                     ),
                   ),
                   ],
                     ),
                   ),],
                   ),
        ),
      ),
   )
    );
  }
}